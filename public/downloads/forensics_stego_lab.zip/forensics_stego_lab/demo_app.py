#!/usr/bin/env python3
"""
Demo web app for the Digital Forensics Lab (runs fully offline, standard library
+ NumPy/Pillow only, no API keys).

Run:    python demo_app.py
Open:   http://127.0.0.1:8000
Use:    upload the stego image (e.g. puppy_stego.png), enter the password if
        there is one, and the hidden PDF opens on the page.

Needs stego_tool.py in the same folder.
"""
import hashlib
import io
import zlib
from http.server import BaseHTTPRequestHandler, HTTPServer

import numpy as np
from PIL import Image

import stego_tool as st

HOST, PORT = "127.0.0.1", 8000  # local only, not exposed to the network

PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Forensics Lab - Hidden File Extractor</title>
<style>
  body{font-family:system-ui,Arial,sans-serif;margin:0;background:#0f172a;color:#e2e8f0}
  header{padding:18px 28px;background:#1e293b;border-bottom:1px solid #334155}
  h1{margin:0;font-size:20px} p.sub{margin:4px 0 0;color:#94a3b8;font-size:14px}
  main{max-width:1000px;margin:24px auto;padding:0 20px}
  .card{background:#1e293b;border:1px solid #334155;border-radius:10px;padding:20px;margin-bottom:20px}
  label{display:block;margin:10px 0 4px;font-size:14px;color:#cbd5e1}
  input[type=file],input[type=password]{width:100%;padding:10px;border-radius:6px;border:1px solid #475569;
    background:#0f172a;color:#e2e8f0;box-sizing:border-box}
  button{margin-top:16px;padding:10px 20px;border:0;border-radius:6px;background:#38bdf8;color:#0f172a;
    font-weight:600;cursor:pointer;font-size:15px}
  button:disabled{opacity:.5;cursor:wait}
  #preview{max-width:100%;max-height:260px;border-radius:8px;margin-top:12px;display:none}
  #status{margin-top:14px;font-size:14px;white-space:pre-line}
  .ok{color:#4ade80}.bad{color:#f87171}
  iframe{width:100%;height:720px;border:1px solid #334155;border-radius:8px;background:#fff;margin-top:12px}
  a.btn{display:inline-block;margin:10px 10px 0 0;color:#38bdf8}
  code{background:#0f172a;padding:2px 6px;border-radius:4px}
</style></head><body>
<header><h1>Digital Forensics Lab - Steganography Extractor</h1>
<p class="sub">Upload an image. If it hides a file, the file is recovered and opened here.</p></header>
<main>
 <div class="card">
  <label for="img">Choose the suspect image (PNG). The hidden file opens automatically.</label>
  <input type="file" id="img" accept="image/png">
  <img id="preview" alt="selected image preview">
  <label for="pw">Password (only needed if the image asks for it, then press Enter)</label>
  <input type="password" id="pw" placeholder="optional">
  <button id="go">Read again</button>
  <div id="status"></div>
 </div>
 <div class="card" id="dcard" style="display:none">
  <strong>Detector verdict</strong>
  <div id="dverdict" style="font-size:20px;margin:8px 0"></div>
  <ul id="dreasons"></ul>
  <div id="dratios" style="color:#94a3b8;font-size:13px"></div>
 </div>
 <div class="card" id="result" style="display:none">
  <strong>Recovered file</strong>
  <div id="meta"></div>
  <a class="btn" id="open" target="_blank">Open in new tab</a>
  <a class="btn" id="dl">Download</a>
  <iframe id="viewer" title="Recovered PDF"></iframe>
 </div>
</main>
<script>
const $ = id => document.getElementById(id);
$('img').onchange = e => {
  const f = e.target.files[0]; if(!f) return;
  $('preview').src = URL.createObjectURL(f); $('preview').style.display='block';
  run();   // start reading automatically as soon as the image is chosen
};
$('pw').addEventListener('keydown', e => { if(e.key==='Enter') run(); });
async function detect(f){
  // textContent only: names inside an image are untrusted data
  try{
    const r = await fetch('/detect',{method:'POST',body:f});
    const j = await r.json();
    if(j.error) throw new Error(j.error);
    $('dverdict').textContent = j.verdict;
    $('dverdict').className = j.verdict==='High risk' ? 'bad' : (j.verdict==='Clean' ? 'ok' : '');
    $('dreasons').replaceChildren(...j.reasons.map(t => { const li=document.createElement('li'); li.textContent=t; return li; }));
    $('dratios').textContent = 'LSB ratios  R '+j.lsb_ratios.R+'  G '+j.lsb_ratios.G+'  B '+j.lsb_ratios.B+'  -  '+j.lsb_ratio_note;
    $('dcard').style.display = 'block';
  }catch(err){ $('dcard').style.display='none'; }
}
async function run(){
  const f = $('img').files[0];
  if(!f){ $('status').className='bad'; $('status').textContent='Please choose an image first.'; return; }
  $('go').disabled = true; $('result').style.display='none';
  $('status').className=''; $('status').textContent='Reading hidden bits from the image...';
  await detect(f);
  try{
    const r = await fetch('/extract',{method:'POST',headers:{'X-Password':$('pw').value},body:f});
    if(!r.ok){ throw new Error(await r.text()); }
    const name = decodeURIComponent(r.headers.get('X-Filename'));
    const blob = new Blob([await r.blob()],{type:'application/pdf'});
    const url = URL.createObjectURL(blob);
    $('viewer').src = url; $('open').href = url; $('dl').href = url; $('dl').download = name;
    $('meta').textContent = 'Name: '+name+'   Size: '+blob.size.toLocaleString()+
      ' bytes   SHA-256: '+r.headers.get('X-Sha256');
    $('result').style.display='block';
    $('result').scrollIntoView({behavior:'smooth'});
    $('status').className='ok';
    $('status').textContent='Hidden file found and verified (SHA-256 matches the original).';
  }catch(err){
    $('status').className='bad'; $('status').textContent=err.message;
    if(/password/i.test(err.message)) $('pw').focus();   // ask for the password, Enter retries
  }
  $('go').disabled = false;
}
$('go').onclick = run;
</script></body></html>
"""


def extract_bytes(png_bytes, password):
    """Return (filename, file_bytes, sha256_hex). Raises ValueError with a friendly message."""
    try:
        arr = np.array(Image.open(io.BytesIO(png_bytes)).convert("RGB"), dtype=np.uint8)
    except Exception:
        raise ValueError("That file is not a readable image.")
    bits = arr.reshape(-1) & 1

    def read(start, count):
        seg = bits[start * 8:(start + count) * 8]
        if seg.size < count * 8:
            raise ValueError("Image is too small or the hidden data is cut off.")
        return np.packbits(seg).tobytes()

    if bits.size < st.FIXED.size * 8:
        raise ValueError("No hidden file found in this image.")
    magic, flags, nlen, osize, psize, sha = st.FIXED.unpack(read(0, st.FIXED.size))
    if magic != st.MAGIC:
        raise ValueError("No hidden file found in this image.")

    name = read(st.FIXED.size, nlen).decode(errors="replace")
    payload = read(st.FIXED.size + nlen, psize)

    if flags & st.FLAG_XOR:
        if not password:
            raise ValueError("A hidden file exists, but it is password protected. Enter the password.")
        payload = st.xor_bytes(payload, password)
    try:
        raw = zlib.decompress(payload) if flags & st.FLAG_ZLIB else payload
    except zlib.error:
        raise ValueError("Wrong password, or the image was modified (resized / converted).")
    if hashlib.sha256(raw).digest() != sha:
        raise ValueError("Integrity check failed: wrong password or image was modified.")
    return name, raw, sha.hex()


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="text/plain; charset=utf-8", extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._send(200, PAGE.encode(), "text/html; charset=utf-8")
        else:
            self._send(404, b"Not found")

    def do_POST(self):
        if self.path not in ("/extract", "/detect"):
            return self._send(404, b"Not found")
        length = int(self.headers.get("Content-Length", 0))
        if length <= 0 or length > 100 * 1024 * 1024:
            return self._send(400, b"Upload a PNG image (max 100 MB).")
        data = self.rfile.read(length)
        if self.path == "/detect":
            import json
            import detector
            try:
                out, code = detector.analyze(data), 200
            except ValueError as e:
                out, code = {"error": str(e)}, 422
            return self._send(code, json.dumps(out).encode(), "application/json")
        try:
            name, raw, sha_hex = extract_bytes(data, self.headers.get("X-Password", ""))
        except ValueError as e:
            return self._send(422, str(e).encode())
        from urllib.parse import quote
        self._send(200, raw, "application/pdf" if raw[:4] == b"%PDF" else "application/octet-stream",
                   {"X-Filename": quote(name), "X-Sha256": sha_hex,
                    "Access-Control-Expose-Headers": "X-Filename, X-Sha256"})

    def log_message(self, fmt, *args):  # simple audit log line per request
        print("[audit]", self.address_string(), fmt % args)


if __name__ == "__main__":
    print(f"Forensics Lab demo running at http://{HOST}:{PORT}  (Ctrl+C to stop)")
    HTTPServer((HOST, PORT), Handler).serve_forever()
