#!/usr/bin/env python3
"""
LSB Steganography tool for the Digital Forensics Lab (fully offline).

Hides ANY file (PDF, text, ZIP ...) inside a PNG image by replacing the last
bit (Least Significant Bit) of every colour value, and extracts it again.

Libraries: NumPy + Pillow + standard library only. No API keys.

Commands
    python stego_tool.py make-cover cover.png --width 2400 --height 1600
    python stego_tool.py capacity cover.png
    python stego_tool.py hide cover.png secret.pdf stego.png [--password PW]
    python stego_tool.py extract stego.png out_folder [--password PW]

Stored layout inside the image (bits, in order):
    FIXED HEADER (56 bytes)
        magic "FSTG1"        5 bytes   marks "something is hidden here"
        flags                1 byte    bit0 = zlib compressed, bit1 = password XOR
        name length          2 bytes
        original file size   8 bytes
        payload size         8 bytes   (size after compression / XOR)
        SHA-256 of original 32 bytes   (integrity proof)
    FILE NAME                n bytes
    PAYLOAD                  payload-size bytes

NOTE: the password option is basic obfuscation (hash-based keystream), NOT
strong encryption. Say so in your report.
"""
import argparse
import hashlib
import os
import struct
import sys
import zlib

import numpy as np
from PIL import Image

MAGIC = b"FSTG1"
FIXED = struct.Struct(">5sBHQQ32s")  # 56 bytes
FLAG_ZLIB = 1
FLAG_XOR = 2


# ------------------------------------------------------------------ helpers
def capacity_bytes(img_array):
    """1 bit per colour value -> width*height*channels / 8 bytes."""
    return img_array.size // 8


def keystream(password, length):
    """Deterministic keystream from the password (PBKDF2 + SHA-256 counter)."""
    key = hashlib.pbkdf2_hmac("sha256", password.encode(), b"fstg-salt", 100_000)
    out = bytearray()
    counter = 0
    while len(out) < length:
        out += hashlib.sha256(key + counter.to_bytes(8, "big")).digest()
        counter += 1
    return bytes(out[:length])


def xor_bytes(data, password):
    ks = np.frombuffer(keystream(password, len(data)), dtype=np.uint8)
    return (np.frombuffer(data, dtype=np.uint8) ^ ks).tobytes()


def load_rgb(path):
    return np.array(Image.open(path).convert("RGB"), dtype=np.uint8)


# ------------------------------------------------------------------ commands
def make_cover(path, width, height, seed=7):
    """Create a natural-looking test image (smooth colours + camera-like noise)."""
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:height, 0:width].astype(np.float32)
    r = 120 + 80 * np.sin(x / 310.0) + 40 * np.cos(y / 170.0)
    g = 110 + 70 * np.sin((x + y) / 420.0) + 30 * np.cos(x / 90.0)
    b = 150 + 60 * np.cos(y / 260.0) - 30 * np.sin(x / 200.0)
    img = np.stack([r, g, b], axis=-1)
    img += rng.normal(0, 2.5, img.shape)  # sensor-like noise
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).save(path)
    print(f"Cover image saved: {path} ({width}x{height})")


def cmd_capacity(cover):
    arr = load_rgb(cover)
    print(f"{cover}: {arr.shape[1]}x{arr.shape[0]}, capacity = "
          f"{capacity_bytes(arr):,} bytes ({capacity_bytes(arr)/1024:.1f} KB)")


def hide(cover, secret, output, password=None):
    arr = load_rgb(cover)
    raw = open(secret, "rb").read()
    sha = hashlib.sha256(raw).digest()

    payload = zlib.compress(raw, 9)
    flags = FLAG_ZLIB
    if password:
        payload = xor_bytes(payload, password)
        flags |= FLAG_XOR

    name = os.path.basename(secret).encode()
    blob = FIXED.pack(MAGIC, flags, len(name), len(raw), len(payload), sha) + name + payload

    cap = capacity_bytes(arr)
    if len(blob) > cap:
        sys.exit(f"ERROR: needs {len(blob):,} bytes but cover holds only {cap:,}. "
                 f"Use a larger cover image.")

    bits = np.unpackbits(np.frombuffer(blob, dtype=np.uint8))
    flat = arr.reshape(-1).copy()
    flat[:bits.size] = (flat[:bits.size] & 0xFE) | bits  # overwrite last bit
    Image.fromarray(flat.reshape(arr.shape)).save(output, format="PNG")  # lossless

    print(f"Hidden '{os.path.basename(secret)}' ({len(raw):,} bytes -> {len(payload):,} stored)")
    print(f"Capacity used: {len(blob)/cap*100:.1f}% of {cap:,} bytes")
    print(f"SHA-256 of original: {sha.hex()}")
    print(f"Saved: {output}  (do NOT resize, crop or convert to JPEG)")


def extract(stego, outdir, password=None):
    arr = load_rgb(stego)
    flat = arr.reshape(-1) & 1

    def read_bytes(start_byte, count):
        seg = flat[start_byte * 8:(start_byte + count) * 8]
        if seg.size < count * 8:
            sys.exit("ERROR: image too small / data truncated.")
        return np.packbits(seg).tobytes()

    magic, flags, nlen, osize, psize, sha = FIXED.unpack(read_bytes(0, FIXED.size))
    if magic != MAGIC:
        sys.exit("No hidden file found (magic marker missing).")

    name = read_bytes(FIXED.size, nlen).decode(errors="replace")
    payload = read_bytes(FIXED.size + nlen, psize)

    if flags & FLAG_XOR:
        if not password:
            sys.exit("This file is password protected. Use --password.")
        payload = xor_bytes(payload, password)
    try:
        raw = zlib.decompress(payload) if flags & FLAG_ZLIB else payload
    except zlib.error:
        sys.exit("SHA-256 check: MISMATCH - wrong password or corrupted image.")

    ok = hashlib.sha256(raw).digest() == sha
    os.makedirs(outdir, exist_ok=True)
    out = os.path.join(outdir, os.path.basename(name))  # basename blocks path tricks
    open(out, "wb").write(raw)
    print(f"Recovered: {out} ({len(raw):,} bytes)")
    print("SHA-256 check:", "MATCH - file intact" if ok else "MISMATCH - wrong password or corrupted")
    if not ok:
        sys.exit(1)


# ------------------------------------------------------------------ CLI
def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("make-cover"); c.add_argument("out")
    c.add_argument("--width", type=int, default=2400); c.add_argument("--height", type=int, default=1600)
    c = sub.add_parser("capacity"); c.add_argument("cover")
    c = sub.add_parser("hide"); c.add_argument("cover"); c.add_argument("secret")
    c.add_argument("output"); c.add_argument("--password")
    c = sub.add_parser("extract"); c.add_argument("stego"); c.add_argument("outdir")
    c.add_argument("--password")

    a = p.parse_args()
    if a.cmd == "make-cover": make_cover(a.out, a.width, a.height)
    elif a.cmd == "capacity": cmd_capacity(a.cover)
    elif a.cmd == "hide": hide(a.cover, a.secret, a.output, a.password)
    else: extract(a.stego, a.outdir, a.password)


if __name__ == "__main__":
    main()
