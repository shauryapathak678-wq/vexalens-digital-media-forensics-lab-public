@echo off
REM Windows: double-click to install requirements and start the demo
python -m pip install -r requirements.txt
start http://127.0.0.1:8000
python demo_app.py
pause
