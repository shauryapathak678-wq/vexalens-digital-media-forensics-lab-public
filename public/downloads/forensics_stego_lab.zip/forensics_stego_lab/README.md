# Forensics Lab - Hidden File (Steganography) Module

Hides any file (e.g. a PDF) inside a PNG image using LSB steganography and
recovers it again. Fully offline, no API keys. Needs Python 3.9+, NumPy, Pillow.

## Folder contents

| File | Purpose |
|---|---|
| `stego_tool.py` | Core tool + command line (hide / extract / capacity / make-cover) |
| `detector.py` | Steganography detector: finds the hidden-file marker, appended data, LSB ratios (`python detector.py image.png`) |
| `demo_app.py` | Local web page: upload image -> detector verdict, then the hidden PDF opens |
| `puppy_stego_nopw.png` | Sample image with the sorting report hidden inside, NO password (opens instantly) |
| `puppy_stego.png` | Same, but protected with password `lab123` |
| `puppy_cover.png` | Same image with nothing hidden (for comparison) |
| `requirements.txt` | `pip install -r requirements.txt` |
| `run.bat` / `run.sh` | One-click start (Windows / Linux, macOS) |

## Quick start

1. Install Python, then run `run.bat` (Windows) or `./run.sh` (Linux/macOS).
   Or manually: `pip install -r requirements.txt` then `python demo_app.py`.
2. Open http://127.0.0.1:8000
3. Upload `puppy_stego_nopw.png`: the page starts reading it automatically and the
   hidden PDF opens. For `puppy_stego.png` the page asks for the password
   (`lab123`), then press Enter.

## Detector

`python detector.py puppy_stego_nopw.png` prints a verdict (Clean / Needs review / High risk).
The web page runs it automatically before extracting.

- High risk: the tool's FSTG1 hidden-file marker was found and validated.
- Needs review: extra bytes were found after the PNG end marker.
- LSB ratios are shown only as a clue. Noisy photos are about 0.50 on every channel even
  when nothing is hidden, so a ratio near 0.50 is NOT proof of hidden data.

## Command line

    python stego_tool.py capacity puppy_cover.png
    python stego_tool.py hide puppy_cover.png my_file.pdf out.png --password MYPASS
    python stego_tool.py extract out.png recovered_folder --password MYPASS

## Use it inside your own project (Python)

Put `stego_tool.py` and `demo_app.py` in your project folder, then:

    from stego_tool import hide, extract
    hide("cover.png", "secret.pdf", "stego.png", password="lab123")
    extract("stego.png", "recovered", password="lab123")

    # read the hidden file from uploaded image bytes (no file written):
    from demo_app import extract_bytes
    name, file_bytes, sha256 = extract_bytes(open("stego.png", "rb").read(), "lab123")

## How it works

Every colour value (0-255) in the image ends with one "least significant bit".
Changing it alters the colour by at most 1, which the eye cannot see. The tool
stores a small header (marker, file name, size, SHA-256) followed by the
zlib-compressed file in those bits. Extraction reads the bits back, decompresses
and checks the SHA-256 to prove the file is intact.

## Important rules

- Use PNG only. JPEG compression, resizing, cropping or screenshots destroy the data.
- Capacity = width x height x 3 / 8 bytes (a 2400x1600 image holds about 1.4 MB).
- The password is basic obfuscation (hash-based keystream), NOT strong encryption.
- Detection: the image's last bits look random and carry a marker, so a forensic
  detector (chi-square / LSB analysis) can flag it. Hidden from the eye, not from analysis.
- Local only: the web demo listens on 127.0.0.1 and never sends data anywhere.
