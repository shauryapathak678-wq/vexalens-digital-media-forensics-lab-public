"""
Steganography detector for the Digital Forensics Lab (offline, NumPy + Pillow).

Checks a PNG for:
  1. The hidden-file marker written by stego_tool.py (FSTG1 header in the LSB stream),
     validated so random noise cannot trigger it by accident.
  2. Data appended after the PNG end chunk (IEND).
  3. LSB channel ratios (reported as a CLUE only - noisy photos are ~0.50 anyway).

Usage:  python detector.py image.png
"""
import hashlib
import json
import struct
import sys
import zlib

import numpy as np
from PIL import Image

import stego_tool as st


def _read(bits, start_byte, count):
    seg = bits[start_byte * 8:(start_byte + count) * 8]
    if seg.size < count * 8:
        return None
    return np.packbits(seg).tobytes()


def analyze(png_bytes):
    import io
    try:
        arr = np.array(Image.open(io.BytesIO(png_bytes)).convert("RGB"), dtype=np.uint8)
    except Exception:
        raise ValueError("That file is not a readable image.")

    h, w, _ = arr.shape
    bits = arr.reshape(-1) & 1
    capacity = arr.size // 8
    reasons, level = [], "Clean"

    # --- LSB ratios (clue only) -------------------------------------------
    ratios = {c: round(float((arr[..., i] & 1).mean()), 4) for i, c in enumerate("RGB")}
    near_half = all(abs(v - 0.5) < 0.02 for v in ratios.values())

    # --- 1. FSTG1 hidden-file header --------------------------------------
    hidden = None
    head = _read(bits, 0, st.FIXED.size)
    if head is not None:
        magic, flags, nlen, osize, psize, sha = st.FIXED.unpack(head)
        if magic == st.MAGIC:
            raw_name = _read(bits, st.FIXED.size, nlen) if nlen <= 255 else None
            plausible = (
                raw_name is not None
                and st.FIXED.size + nlen + psize <= capacity   # must fit in the image
                and flags & ~(st.FLAG_ZLIB | st.FLAG_XOR) == 0  # only known flags
                and 0 < osize < 2 ** 40
            )
            if plausible:
                name = raw_name.decode(errors="replace")
                protected = bool(flags & st.FLAG_XOR)
                verified = None
                if not protected:  # can fully prove integrity without a password
                    payload = _read(bits, st.FIXED.size + nlen, psize)
                    try:
                        data = zlib.decompress(payload) if flags & st.FLAG_ZLIB else payload
                        verified = hashlib.sha256(data).digest() == sha
                    except zlib.error:
                        verified = False
                hidden = {
                    "file_name": name,
                    "original_size": osize,
                    "stored_size": psize,
                    "password_protected": protected,
                    "sha256_verified": verified,
                    "sha256": sha.hex(),
                    "capacity_used_percent": round((st.FIXED.size + nlen + psize) / capacity * 100, 1),
                }
                level = "High risk"
                reasons.append(
                    f"Hidden-file marker FSTG1 found in the LSB stream: '{name}' "
                    f"({osize:,} bytes, {hidden['capacity_used_percent']}% of image capacity)."
                )
                if protected:
                    reasons.append("The hidden file is password protected.")
                elif verified:
                    reasons.append("Its SHA-256 matches, so the hidden file is intact and recoverable.")

    # --- 2. Data appended after PNG IEND -----------------------------------
    appended = 0
    i = png_bytes.rfind(b"IEND")
    if png_bytes[:8] == b"\x89PNG\r\n\x1a\n" and i != -1:
        appended = max(0, len(png_bytes) - (i + 8))  # IEND + 4-byte CRC
    if appended:
        reasons.append(f"{appended:,} extra bytes were found after the PNG end marker.")
        if level == "Clean":
            level = "Needs review"

    if level == "Clean":
        reasons.append("No hidden-file marker and no appended data found.")
        reasons.append(
            "LSB ratios near 0.50 are normal for noisy photos, so they are a clue, not proof. "
            "Hidden data that does not use this tool's marker could still exist."
            if near_half else
            "LSB ratios are not close to 0.50, which is natural for this image."
        )

    return {
        "verdict": level,
        "reasons": reasons,
        "width": w, "height": h,
        "lsb_ratios": ratios,
        "lsb_ratio_note": ("Near 0.50 on all channels: a clue only, common in noisy images."
                           if near_half else "Not close to 0.50."),
        "appended_bytes": appended,
        "hidden_file": hidden,
        "capacity_bytes": capacity,
        "sha256_of_image": hashlib.sha256(png_bytes).hexdigest(),
    }


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Usage: python detector.py image.png")
    print(json.dumps(analyze(open(sys.argv[1], "rb").read()), indent=2))
