#!/usr/bin/env bash
# Linux / macOS: ./run.sh
python3 -m pip install -r requirements.txt
echo "Open http://127.0.0.1:8000 in your browser"
python3 demo_app.py
